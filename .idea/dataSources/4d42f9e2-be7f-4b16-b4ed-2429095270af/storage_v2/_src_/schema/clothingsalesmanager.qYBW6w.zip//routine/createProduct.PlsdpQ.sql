create
    definer = root@localhost procedure createProduct(IN $productName varchar(100), IN $productCategoryId int,
                                                     IN $productPrice int, IN $productQuantity int,
                                                     IN $productDescription varchar(100), IN $imageLink varchar(100))
BEGIN
    INSERT INTO product(productName, productCategoryId, productPrice, productQuantity,productDescription, productStatus)
        VALUE ($productName, $productCategoryId, $productPrice, $productQuantity, $productDescription, 1);
    SET @productId = 0;
    SET @productId = (select productId from product order by productId DESC LIMIT 1);
    INSERT INTO productimage(productId, imageLink)  value (@productId, $imageLink);
END;

