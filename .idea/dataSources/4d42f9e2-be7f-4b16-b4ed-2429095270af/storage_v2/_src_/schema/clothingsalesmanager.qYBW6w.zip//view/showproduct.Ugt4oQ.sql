create definer = root@localhost view showproduct as
select `clothingsalesmanager`.`product`.`productId`          AS `productId`,
       `clothingsalesmanager`.`product`.`productName`        AS `productName`,
       `c`.`CategoryName`                                    AS `CategoryName`,
       `clothingsalesmanager`.`product`.`productPrice`       AS `productPrice`,
       `clothingsalesmanager`.`product`.`productQuantity`    AS `productQuantity`,
       `clothingsalesmanager`.`product`.`productDescription` AS `productDescription`,
       `clothingsalesmanager`.`product`.`productStatus`      AS `productStatus`
from (`clothingsalesmanager`.`product`
         join `clothingsalesmanager`.`category` `c`
              on ((`clothingsalesmanager`.`product`.`productCategoryId` = `c`.`CategoryId`)));

