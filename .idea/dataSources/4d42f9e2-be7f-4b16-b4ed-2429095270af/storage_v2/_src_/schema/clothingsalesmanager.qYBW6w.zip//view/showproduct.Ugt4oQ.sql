create definer = root@localhost view showproduct as
select `clothingsalesmanager`.`product`.`productId`          AS `productId`,
       `clothingsalesmanager`.`product`.`productCategoryId`  AS `productCategoryId`,
       `clothingsalesmanager`.`product`.`productName`        AS `productName`,
       `c`.`CategoryName`                                    AS `CategoryName`,
       `clothingsalesmanager`.`product`.`productPrice`       AS `productPrice`,
       `clothingsalesmanager`.`product`.`productQuantity`    AS `productQuantity`,
       `clothingsalesmanager`.`product`.`productDescription` AS `productDescription`,
       `clothingsalesmanager`.`product`.`productStatus`      AS `productStatus`,
       `i`.`imageLink`                                       AS `imageLink`
from ((`clothingsalesmanager`.`product` join `clothingsalesmanager`.`category` `c`
       on ((`clothingsalesmanager`.`product`.`productCategoryId` =
            `c`.`CategoryId`))) join `clothingsalesmanager`.`productimage` `i`
      on ((`clothingsalesmanager`.`product`.`productId` = `i`.`productId`)));

