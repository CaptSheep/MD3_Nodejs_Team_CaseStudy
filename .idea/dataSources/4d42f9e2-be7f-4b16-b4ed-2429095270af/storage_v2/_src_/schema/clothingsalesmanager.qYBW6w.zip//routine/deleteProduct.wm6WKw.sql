create
    definer = root@localhost procedure deleteProduct(IN $productId int)
BEGIN
	DELETE from ProductImage where productId = $productId;
    DELETE from Product where productId = $productId; 
END;

