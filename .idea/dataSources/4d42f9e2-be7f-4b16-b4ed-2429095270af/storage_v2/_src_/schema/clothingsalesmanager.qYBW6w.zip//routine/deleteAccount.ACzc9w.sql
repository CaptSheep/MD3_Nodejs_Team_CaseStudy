create
    definer = root@localhost procedure deleteAccount(IN $customerId int)
BEGIN
    DELETE FROM rolecustomerdetails where customerId = $customerId;
    DELETE FROM customer where customerId = $customerId;
    END;

